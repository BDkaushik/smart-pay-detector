
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

let isPaymentReceived = false;

app.use(express.json());

app.post('/payment-status', (req, res) => {
  const event = req.body.event;
  console.log("Webhook Received:", event);
  if (event === "PAYMENT_SUCCESS") {
    isPaymentReceived = true;
  }
  res.sendStatus(200);
});

app.get('/check-payment', (req, res) => {
  res.json({ payment: isPaymentReceived });
  if (isPaymentReceived) isPaymentReceived = false;
});

app.get('/', (req, res) => {
  res.send("Server is running - Kaushik bhai 🧠💸");
});

app.listen(port, () => {
  console.log(`Server running at port ${port}`);
});
