
# Cashfree ESP32 Server

This server detects payments via webhook and allows an ESP32 to check if a payment has been received.

## Endpoints

- POST `/payment-status` – Cashfree webhook triggers this
- GET `/check-payment` – ESP32 polls this to detect payment
